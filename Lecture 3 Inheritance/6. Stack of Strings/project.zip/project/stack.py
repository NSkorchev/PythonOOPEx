from typing import List


class Stack:
    def __init__(self):
        self.data: List[str] = []

    def push(self, element):
        self.data.append(element)

    def pop(self):
        last_el = self.data.pop()
        return last_el

    def top(self):
        return self.data[-1]

    def is_empty(self):
        if len(self.data) == 0:
            return "True"
        else:
            return "False"

    def __str__(self):
        result = ', '.join(self.data)
        return f"[{result}]"


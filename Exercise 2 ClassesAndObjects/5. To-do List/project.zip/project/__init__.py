# Read user input

# Logic

# Output
